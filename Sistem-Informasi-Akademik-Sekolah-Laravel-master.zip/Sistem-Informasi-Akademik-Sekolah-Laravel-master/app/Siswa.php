<?php

namespace App;

use Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Siswa extends Model
{
    use SoftDeletes;

    protected $fillable = ['no_induk', 'nis', 'nama_Siswa', 'kelas_id', 'jk', 'telp', 'tmp_lahir', 'tgl_lahir', 'foto'];

    public function kelas()
    {
        return $this->belongsTo('App\Kelas')->withDefault();
    }

    public function ulangan($id)
    {
        $Guru = Guru::where('id_card', Auth::user()->id_card)->first();
        $nilai = Ulangan::where('Siswa_id', $id)->where('Guru_id', $Guru->id)->first();
        return $nilai;
    }

    public function sikap($id)
    {
        $Guru = Guru::where('id_card', Auth::user()->id_card)->first();
        $nilai = Sikap::where('Siswa_id', $id)->where('Guru_id', $Guru->id)->first();
        return $nilai;
    }

    public function nilai($id)
    {
        $Guru = Guru::where('id_card', Auth::user()->id_card)->first();
        $nilai = Rapot::where('Siswa_id', $id)->where('Guru_id', $Guru->id)->first();
        return $nilai;
    }

    protected $table = 'Siswa';
}
