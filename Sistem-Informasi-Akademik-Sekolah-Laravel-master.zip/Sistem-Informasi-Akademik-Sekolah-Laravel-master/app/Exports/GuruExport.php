<?php

namespace App\Exports;

use App\Guru;
use Maatwebsite\Excel\Concerns\FromCollection;

class GuruExport implements FromCollection
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        $Guru = Guru::join('mapel', 'mapel.id', '=', 'Guru.mapel_id')->select('Guru.nama_Guru', 'Guru.nip', 'Guru.jk', 'mapel.nama_mapel')->get();
        return $Guru;
    }
}
