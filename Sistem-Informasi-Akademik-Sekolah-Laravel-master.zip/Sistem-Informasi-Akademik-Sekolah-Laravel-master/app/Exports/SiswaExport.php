<?php

namespace App\Exports;

use App\Siswa;
use Maatwebsite\Excel\Concerns\FromCollection;

class SiswaExport implements FromCollection
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        $Siswa = Siswa::join('kelas', 'kelas.id', '=', 'Siswa.kelas_id')->select('Siswa.nama_Siswa', 'Siswa.no_induk', 'Siswa.jk', 'kelas.nama_kelas')->get();
        return $Siswa;
    }
}
