<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Absen extends Model
{
    protected $fillable = ['Guru_id', 'tanggal', 'kehadiran_id'];

    public function Guru()
    {
        return $this->belongsTo('App\Guru')->withDefault();
    }

    public function kehadiran()
    {
        return $this->belongsTo('App\Kehadiran')->withDefault();
    }

    protected $table = 'absensi_Guru';
}
