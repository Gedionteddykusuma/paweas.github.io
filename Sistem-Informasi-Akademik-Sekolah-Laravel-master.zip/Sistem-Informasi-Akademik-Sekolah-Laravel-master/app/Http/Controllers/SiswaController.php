<?php

namespace App\Http\Controllers;

use PDF;
use App\User;
use App\Kelas;
use App\Siswa;
use App\Exports\SiswaExport;
use App\Imports\SiswaImport;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;

class SiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kelas = Kelas::OrderBy('nama_kelas', 'asc')->get();
        return view('admin.Siswa.index', compact('kelas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'no_induk' => 'required|string|unique:Siswa',
            'nama_Siswa' => 'required',
            'jk' => 'required',
            'kelas_id' => 'required'
        ]);

        if ($request->foto) {
            $foto = $request->foto;
            $new_foto = date('siHdmY') . "_" . $foto->getClientOriginalName();
            $foto->move('uploads/Siswa/', $new_foto);
            $nameFoto = 'uploads/Siswa/' . $new_foto;
        } else {
            if ($request->jk == 'L') {
                $nameFoto = 'uploads/Siswa/52471919042020_male.jpg';
            } else {
                $nameFoto = 'uploads/Siswa/50271431012020_female.jpg';
            }
        }

        Siswa::create([
            'no_induk' => $request->no_induk,
            'nis' => $request->nis,
            'nama_Siswa' => $request->nama_Siswa,
            'jk' => $request->jk,
            'kelas_id' => $request->kelas_id,
            'telp' => $request->telp,
            'tmp_lahir' => $request->tmp_lahir,
            'tgl_lahir' => $request->tgl_lahir,
            'foto' => $nameFoto
        ]);

        return redirect()->back()->with('success', 'Berhasil menambahkan data Siswa baru!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $id = Crypt::decrypt($id);
        $Siswa = Siswa::findorfail($id);
        return view('admin.Siswa.details', compact('Siswa'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $id = Crypt::decrypt($id);
        $Siswa = Siswa::findorfail($id);
        $kelas = Kelas::all();
        return view('admin.Siswa.edit', compact('Siswa', 'kelas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'nama_Siswa' => 'required',
            'jk' => 'required',
            'kelas_id' => 'required'
        ]);

        $Siswa = Siswa::findorfail($id);
        $user = User::where('no_induk', $Siswa->no_induk)->first();
        if ($user) {
            $user_data = [
                'name' => $request->nama_Siswa
            ];
            $user->update($user_data);
        } else {
        }
        $Siswa_data = [
            'nis' => $request->nis,
            'nama_Siswa' => $request->nama_Siswa,
            'jk' => $request->jk,
            'kelas_id' => $request->kelas_id,
            'telp' => $request->telp,
            'tmp_lahir' => $request->tmp_lahir,
            'tgl_lahir' => $request->tgl_lahir,
        ];
        $Siswa->update($Siswa_data);

        return redirect()->route('Siswa.index')->with('success', 'Data Siswa berhasil diperbarui!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $Siswa = Siswa::findorfail($id);
        $countUser = User::where('no_induk', $Siswa->no_induk)->count();
        if ($countUser >= 1) {
            $user = User::where('no_induk', $Siswa->no_induk)->first();
            $Siswa->delete();
            $user->delete();
            return redirect()->back()->with('warning', 'Data Siswa berhasil dihapus! (Silahkan cek trash data Siswa)');
        } else {
            $Siswa->delete();
            return redirect()->back()->with('warning', 'Data Siswa berhasil dihapus! (Silahkan cek trash data Siswa)');
        }
    }

    public function trash()
    {
        $Siswa = Siswa::onlyTrashed()->get();
        return view('admin.Siswa.trash', compact('Siswa'));
    }

    public function restore($id)
    {
        $id = Crypt::decrypt($id);
        $Siswa = Siswa::withTrashed()->findorfail($id);
        $countUser = User::withTrashed()->where('no_induk', $Siswa->no_induk)->count();
        if ($countUser >= 1) {
            $user = User::withTrashed()->where('no_induk', $Siswa->no_induk)->first();
            $Siswa->restore();
            $user->restore();
            return redirect()->back()->with('info', 'Data Siswa berhasil direstore! (Silahkan cek data Siswa)');
        } else {
            $Siswa->restore();
            return redirect()->back()->with('info', 'Data Siswa berhasil direstore! (Silahkan cek data Siswa)');
        }
    }

    public function kill($id)
    {
        $Siswa = Siswa::withTrashed()->findorfail($id);
        $countUser = User::withTrashed()->where('no_induk', $Siswa->no_induk)->count();
        if ($countUser >= 1) {
            $user = User::withTrashed()->where('no_induk', $Siswa->no_induk)->first();
            $Siswa->forceDelete();
            $user->forceDelete();
            return redirect()->back()->with('success', 'Data Siswa berhasil dihapus secara permanent');
        } else {
            $Siswa->forceDelete();
            return redirect()->back()->with('success', 'Data Siswa berhasil dihapus secara permanent');
        }
    }

    public function ubah_foto($id)
    {
        $id = Crypt::decrypt($id);
        $Siswa = Siswa::findorfail($id);
        return view('admin.Siswa.ubah-foto', compact('Siswa'));
    }

    public function update_foto(Request $request, $id)
    {
        $this->validate($request, [
            'foto' => 'required'
        ]);

        $Siswa = Siswa::findorfail($id);
        $foto = $request->foto;
        $new_foto = date('s' . 'i' . 'H' . 'd' . 'm' . 'Y') . "_" . $foto->getClientOriginalName();
        $Siswa_data = [
            'foto' => 'uploads/Siswa/' . $new_foto,
        ];
        $foto->move('uploads/Siswa/', $new_foto);
        $Siswa->update($Siswa_data);

        return redirect()->route('Siswa.index')->with('success', 'Berhasil merubah foto!');
    }

    public function view(Request $request)
    {
        $Siswa = Siswa::OrderBy('nama_Siswa', 'asc')->where('kelas_id', $request->id)->get();

        foreach ($Siswa as $val) {
            $newForm[] = array(
                'kelas' => $val->kelas->nama_kelas,
                'no_induk' => $val->no_induk,
                'nama_Siswa' => $val->nama_Siswa,
                'jk' => $val->jk,
                'foto' => $val->foto
            );
        }

        return response()->json($newForm);
    }

    public function cetak_pdf(Request $request)
    {
        $Siswa = Siswa::OrderBy('nama_Siswa', 'asc')->where('kelas_id', $request->id)->get();
        $kelas = Kelas::findorfail($request->id);

        $pdf = PDF::loadView('Siswa-pdf', ['Siswa' => $Siswa, 'kelas' => $kelas]);
        return $pdf->stream();
        // return $pdf->stream('jadwal-pdf.pdf');
    }

    public function kelas($id)
    {
        $id = Crypt::decrypt($id);
        $Siswa = Siswa::where('kelas_id', $id)->OrderBy('nama_Siswa', 'asc')->get();
        $kelas = Kelas::findorfail($id);
        return view('admin.Siswa.show', compact('Siswa', 'kelas'));
    }

    public function export_excel()
    {
        return Excel::download(new SiswaExport, 'Siswa.xlsx');
    }

    public function import_excel(Request $request)
    {
        $this->validate($request, [
            'file' => 'required|mimes:csv,xls,xlsx'
        ]);
        $file = $request->file('file');
        $nama_file = rand() . $file->getClientOriginalName();
        $file->move('file_Siswa', $nama_file);
        Excel::import(new SiswaImport, public_path('/file_Siswa/' . $nama_file));
        return redirect()->back()->with('success', 'Data Siswa Berhasil Diimport!');
    }

    public function deleteAll()
    {
        $Siswa = Siswa::all();
        if ($Siswa->count() >= 1) {
            Siswa::whereNotNull('id')->delete();
            Siswa::withTrashed()->whereNotNull('id')->forceDelete();
            return redirect()->back()->with('success', 'Data table Siswa berhasil dihapus!');
        } else {
            return redirect()->back()->with('warning', 'Data table Siswa kosong!');
        }
    }
}
